# execute as <玩家> run function dbchud:clear
function dbchud:_ensure_id
execute store result storage dbchud:s id int 1 run scoreboard players get @s dbchud.id
function dbchud:_clear2 with storage dbchud:s
