execute store result score #i dbchud.calc run random value 0..154
execute store result storage dbchud:st idx int 1 run scoreboard players get #i dbchud.calc
function dbchud:_stress_getch with storage dbchud:st
function dbchud:_stress_cat with storage dbchud:st
scoreboard players remove #n dbchud.calc 1
function dbchud:_stress_loop
