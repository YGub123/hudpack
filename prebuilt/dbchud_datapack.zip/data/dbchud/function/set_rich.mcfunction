$data modify storage dbchud:rz parts set value $(parts)
data modify storage dbchud:rz acc set value ""
function dbchud:_rz_loop
function dbchud:_ensure_id
execute store result storage dbchud:s id int 1 run scoreboard players get @s dbchud.id
$data modify storage dbchud:s comp set value {x:$(x),y:$(y),color:"$(color)",effect:"$(effect)",scale:$(scale),align:"$(align)"}
data modify storage dbchud:s comp.text set from storage dbchud:rz acc
$data modify storage dbchud:s name set value "$(name)"
function dbchud:_set2 with storage dbchud:s
