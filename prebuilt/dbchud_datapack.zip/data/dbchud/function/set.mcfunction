# execute as <玩家> run function dbchud:set {name,x,y,color,text,effect,scale,align}
#   align = left(左) / center(中) / right(右)
function dbchud:_ensure_id
execute store result storage dbchud:s id int 1 run scoreboard players get @s dbchud.id
$data modify storage dbchud:s comp set value {x:$(x),y:$(y),color:"$(color)",text:"$(text)",effect:"$(effect)",scale:$(scale),align:"$(align)"}
$data modify storage dbchud:s name set value "$(name)"
function dbchud:_set2 with storage dbchud:s
