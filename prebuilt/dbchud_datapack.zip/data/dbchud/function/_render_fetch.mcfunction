data remove storage dbchud:cur comp
$data modify storage dbchud:cur comp set from storage dbchud:data players.p$(idkeep).comps.$(name)
execute if data storage dbchud:cur comp.native run function dbchud:_enc_native with storage dbchud:cur comp
execute if data storage dbchud:cur comp.x run function dbchud:encode with storage dbchud:cur comp
