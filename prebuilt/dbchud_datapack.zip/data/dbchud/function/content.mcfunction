# execute as <玩家> run function dbchud:content {name,text}
function dbchud:_ensure_id
execute store result storage dbchud:s id int 1 run scoreboard players get @s dbchud.id
$data modify storage dbchud:s name set value "$(name)"
$data modify storage dbchud:s text set value "$(text)"
function dbchud:_content2 with storage dbchud:s
