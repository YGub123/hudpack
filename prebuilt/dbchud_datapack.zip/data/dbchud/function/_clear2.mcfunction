$data modify storage dbchud:data players.p$(id) set value {comps:{},order:[]}
function dbchud:_render
