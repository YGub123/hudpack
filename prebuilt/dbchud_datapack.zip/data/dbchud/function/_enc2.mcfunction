$data modify storage dbchud:tmp rr set from storage dbchud:consts hex[$(r)]
$data modify storage dbchud:tmp gg set from storage dbchud:consts hex[$(g)]
$data modify storage dbchud:tmp bb set from storage dbchud:consts hex[$(b)]
$data modify storage dbchud:tmp open set from storage dbchud:consts rulerO[$(sh)]
$data modify storage dbchud:tmp close set from storage dbchud:consts rulerC[$(sh)]
# 按 align 分左/中/右
execute if data storage dbchud:tmp {align:"center"} run function dbchud:_enc3c with storage dbchud:tmp
execute if data storage dbchud:tmp {align:"right"} run function dbchud:_enc3r with storage dbchud:tmp
execute unless data storage dbchud:tmp {align:"center"} unless data storage dbchud:tmp {align:"right"} run function dbchud:_enc3 with storage dbchud:tmp
