$data modify storage dbchud:st ch set from storage dbchud:st pool[$(idx)]
