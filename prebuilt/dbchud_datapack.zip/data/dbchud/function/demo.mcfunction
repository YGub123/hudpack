# 示例:给自己(@s)显示几个 HUD 组件(含效果 + 字号)
function dbchud:begin
function dbchud:encode {x:5,y:85,color:"red",text:"血量 20/20",effect:"none",scale:1,align:"left"}
function dbchud:encode {x:72,y:6,color:"yellow",text:"时间 12:00",effect:"none",scale:1,align:"left"}
function dbchud:encode {x:50,y:3,color:"white",text:"★ 神经现场 ★",effect:"rainbow",scale:2,align:"center"}
function dbchud:encode {x:46,y:45,color:"aqua",text:"警告",effect:"rotate",scale:1,align:"left"}
function dbchud:encode {x:40,y:70,color:"green",text:"波浪效果ABC",effect:"wave",scale:1,align:"left"}
execute as @s run function dbchud:flush with storage dbchud:build
