# execute as <玩家> run function dbchud:actionbar {text}
# 固定显示在原版 actionbar 的位置
function dbchud:_ensure_id
execute store result storage dbchud:s id int 1 run scoreboard players get @s dbchud.id
$data modify storage dbchud:s comp set value {native:1b,color:"white",text:"$(text)"}
data modify storage dbchud:s name set value "actionbar"
function dbchud:_set2 with storage dbchud:s
