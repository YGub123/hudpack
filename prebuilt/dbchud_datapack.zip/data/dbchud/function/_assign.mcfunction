scoreboard players add #next dbchud.id 1
scoreboard players operation @s dbchud.id = #next dbchud.id
