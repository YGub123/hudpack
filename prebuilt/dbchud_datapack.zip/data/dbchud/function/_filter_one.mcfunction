data modify storage dbchud:flt head set from storage dbchud:flt order[0]
$execute unless data storage dbchud:flt {head:"$(target)"} run data modify storage dbchud:flt out append from storage dbchud:flt head
data remove storage dbchud:flt order[0]
function dbchud:_filter
