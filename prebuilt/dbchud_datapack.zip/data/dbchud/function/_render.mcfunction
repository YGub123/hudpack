function dbchud:_ensure_id
execute store result storage dbchud:r id int 1 run scoreboard players get @s dbchud.id
function dbchud:begin
function dbchud:_render2 with storage dbchud:r
execute if data storage dbchud:build components[1] run function dbchud:flush with storage dbchud:build
