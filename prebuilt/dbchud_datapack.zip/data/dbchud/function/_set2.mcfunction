$execute unless data storage dbchud:data players.p$(id) run data modify storage dbchud:data players.p$(id) set value {comps:{},order:[]}
$execute unless data storage dbchud:data players.p$(id).comps.$(name) run data modify storage dbchud:data players.p$(id).order append value "$(name)"
$data modify storage dbchud:data players.p$(id).comps.$(name) set from storage dbchud:s comp
function dbchud:_render
