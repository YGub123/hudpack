execute if score #n dbchud.calc matches 1.. run function dbchud:_stress_pick
