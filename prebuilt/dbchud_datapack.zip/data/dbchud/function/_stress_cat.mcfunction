$data modify storage dbchud:st acc set value "$(acc)$(ch)"
