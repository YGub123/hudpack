data modify storage dbchud:st acc set value ""
execute store result score #n dbchud.calc run random value 1..12
function dbchud:_stress_loop
function dbchud:_stress_apply
