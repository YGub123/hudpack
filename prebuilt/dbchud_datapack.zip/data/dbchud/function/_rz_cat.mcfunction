$data modify storage dbchud:rz acc set value "$(acc)$(add)"
