# execute as <玩家> run function dbchud:stress —— 开/关随机 actionbar 压测(每 tick 变一次)
# 建议先 /function dbchud:demo2 摆好其它组件,再开压测,盯着 hp/time/title 会不会跟着动。
execute unless score @s dbchud.stress matches -2147483648.. run scoreboard players set @s dbchud.stress 0
scoreboard players operation #o dbchud.calc = @s dbchud.stress
execute if score #o dbchud.calc matches 1.. run scoreboard players set @s dbchud.stress 0
execute if score #o dbchud.calc matches ..0 run scoreboard players set @s dbchud.stress 1
execute if score @s dbchud.stress matches 1.. run tellraw @s {"text":"[DBCHUD] 随机 actionbar 压测 = 开(每 tick 变)","color":"green"}
execute if score @s dbchud.stress matches ..0 run tellraw @s {"text":"[DBCHUD] 随机 actionbar 压测 = 关","color":"yellow"}
