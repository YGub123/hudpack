execute unless score @s dbchud.id matches 1.. run function dbchud:_assign
