# execute as <玩家> run function dbchud:flush with storage dbchud:build
$title @s actionbar $(components)
