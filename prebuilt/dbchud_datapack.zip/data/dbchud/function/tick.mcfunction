execute as @a unless score @s dbchud.id matches 1.. run function dbchud:_assign
scoreboard players add #hb dbchud.id 1
execute if score #hb dbchud.id matches 10.. run function dbchud:_heartbeat
# 随机内容压测:开了的玩家每 tick 换一次 actionbar 内容
execute as @a if score @s dbchud.stress matches 1.. run function dbchud:_stress_gen
