# 有状态示例:给自己(@s)建几个组件(会一直显示,直到 content/remove/clear)
execute as @s run function dbchud:set {name:"hp",x:5,y:85,color:"red",text:"血量 20/20",effect:"none",scale:1,align:"left"}
execute as @s run function dbchud:set {name:"time",x:95,y:6,color:"yellow",text:"12:00",effect:"none",scale:1,align:"right"}
execute as @s run function dbchud:set {name:"title",x:50,y:3,color:"white",text:"★ 神经现场 ★",effect:"rainbow",scale:2,align:"center"}
execute as @s run function dbchud:actionbar {text:"这是代替 actionbar 的默认组件"}
# 改血量:      execute as @s run function dbchud:content {name:"hp",text:"血量 15/20"}
# 改 actionbar:execute as @s run function dbchud:content {name:"actionbar",text:"你捡到了 金锭 x3"}
# 删标题:      execute as @s run function dbchud:remove {name:"title"}
# 全清:        execute as @s run function dbchud:clear
