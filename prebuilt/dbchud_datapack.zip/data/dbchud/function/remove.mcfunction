# execute as <玩家> run function dbchud:remove {name}
function dbchud:_ensure_id
execute store result storage dbchud:s id int 1 run scoreboard players get @s dbchud.id
$data modify storage dbchud:s name set value "$(name)"
function dbchud:_remove2 with storage dbchud:s
