# DBCHUD 初始化
scoreboard objectives add dbchud.calc dummy
scoreboard players set #cw dbchud.calc 16
scoreboard players set #c4 dbchud.calc 4
scoreboard players set #cm1 dbchud.calc -1
data modify storage dbchud:consts hex set value ["00","01","02","03","04","05","06","07","08","09","0A","0B","0C","0D","0E","0F","10","11","12","13","14","15","16","17","18","19","1A","1B","1C","1D","1E","1F","20","21","22","23","24","25","26","27","28","29","2A","2B","2C","2D","2E","2F","30","31","32","33","34","35","36","37","38","39","3A","3B","3C","3D","3E","3F","40","41","42","43","44","45","46","47","48","49","4A","4B","4C","4D","4E","4F","50","51","52","53","54","55","56","57","58","59","5A","5B","5C","5D","5E","5F","60","61","62","63","64","65","66","67","68","69","6A","6B","6C","6D","6E","6F","70","71","72","73","74","75","76","77","78","79","7A","7B","7C","7D","7E","7F","80","81","82","83","84","85","86","87","88","89","8A","8B","8C","8D","8E","8F","90","91","92","93","94","95","96","97","98","99","9A","9B","9C","9D","9E","9F","A0","A1","A2","A3","A4","A5","A6","A7","A8","A9","AA","AB","AC","AD","AE","AF","B0","B1","B2","B3","B4","B5","B6","B7","B8","B9","BA","BB","BC","BD","BE","BF","C0","C1","C2","C3","C4","C5","C6","C7","C8","C9","CA","CB","CC","CD","CE","CF","D0","D1","D2","D3","D4","D5","D6","D7","D8","D9","DA","DB","DC","DD","DE","DF","E0","E1","E2","E3","E4","E5","E6","E7","E8","E9","EA","EB","EC","ED","EE","EF","F0","F1","F2","F3","F4","F5","F6","F7","F8","F9","FA","FB","FC","FD","FE","FF"]
data modify storage dbchud:consts palette set value {"black":0,"dark_blue":1,"dark_green":2,"dark_aqua":3,"dark_red":4,"dark_purple":5,"gold":6,"gray":7,"dark_gray":8,"blue":9,"green":10,"aqua":11,"red":12,"light_purple":13,"yellow":14,"white":15}
data modify storage dbchud:consts effects set value {"none":0,"wave":1,"shake":2,"pulse":3,"rainbow":4,"blink":5,"rotate":6}
data modify storage dbchud:consts presets set value {"gold_wave":112}
data modify storage dbchud:consts rulerO set value ["","","","","","","","","","","","","","","",""]
data modify storage dbchud:consts rulerC set value ["","","","","","","","","","","","","","","",""]
data modify storage dbchud:st pool set value ["血","量","经","验","金","币","生","命","魔","法","攻","击","防","御","速","度","暴","击","闪","避","格","挡","穿","透","治","疗","中","毒","眩","晕","冰","火","雷","风","山","水","木","金","土","日","月","星","辰","龙","虎","、","。","，","！","？","；","：","「","」","『","』","（","）","【","】","〈","〉","《","》","…","—","～","·","Ａ","Ｂ","Ｃ","Ｄ","Ｅ","Ｆ","Ｇ","Ｈ","Ｉ","Ｊ","０","１","２","３","４","５","６","７","８","９","가","나","다","라","마","바","사","아","자","차","A","B","C","D","E","F","G","H","I","J","K","L","a","b","c","d","e","f","g","h","i","j","k","l","0","1","2","3","4","5","6","7","8","9"," ","!","?",".",",","/",":",";","(",")","[","]","{","}","@","#","%","&","+","-","=","<",">"]
scoreboard objectives add dbchud.id dummy
# 随机内容压测开关。/function dbchud:stress 切换
scoreboard objectives add dbchud.stress dummy
scoreboard players set #next dbchud.id 0
scoreboard players set #hb dbchud.id 0
data modify storage dbchud:data players set value {}
# 压测是会话内工具,重载一律归零,防止残留在后台跑
scoreboard players reset * dbchud.stress
tellraw @a {"text":"[DBCHUD] 已加载","color":"aqua"}
