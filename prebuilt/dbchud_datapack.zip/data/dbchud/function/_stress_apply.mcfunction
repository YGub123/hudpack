function dbchud:_ensure_id
execute store result storage dbchud:s id int 1 run scoreboard players get @s dbchud.id
data modify storage dbchud:s comp set value {native:1b,color:"white"}
data modify storage dbchud:s comp.text set from storage dbchud:st acc
data modify storage dbchud:s name set value "actionbar"
function dbchud:_set2 with storage dbchud:s
