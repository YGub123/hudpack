$data remove storage dbchud:data players.p$(id).comps.$(name)
$data modify storage dbchud:flt order set from storage dbchud:data players.p$(id).order
$data modify storage dbchud:flt target set value "$(name)"
data modify storage dbchud:flt out set value []
function dbchud:_filter
$data modify storage dbchud:data players.p$(id).order set from storage dbchud:flt out
function dbchud:_render
