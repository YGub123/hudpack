data modify storage dbchud:rz cur set from storage dbchud:rz parts[0]
execute if data storage dbchud:rz cur.icon run function dbchud:_rz_icon
execute unless data storage dbchud:rz cur.icon run function dbchud:_rz_text
data remove storage dbchud:rz parts[0]
function dbchud:_rz_loop
