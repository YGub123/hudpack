data modify storage dbchud:rz name set from storage dbchud:rz cur.icon
function dbchud:_rz_icon2 with storage dbchud:rz
