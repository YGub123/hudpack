scoreboard players set #hb dbchud.id 0
execute as @a run function dbchud:_render
