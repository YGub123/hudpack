# 追加一个组件到构建缓冲。参数 {x,y,color,text,effect,scale,align}
#   x/y=0~100  color=16色名  effect=none/wave/.../rotate  scale=0.0625~4(支持小数)
$data modify storage dbchud:tmp scaleq set value $(scale)
execute store result score #q dbchud.calc run data get storage dbchud:tmp scaleq 16
scoreboard players remove #q dbchud.calc 1
execute if score #q dbchud.calc matches ..-1 run scoreboard players set #q dbchud.calc 0
execute if score #q dbchud.calc matches 64.. run scoreboard players set #q dbchud.calc 63
scoreboard players operation #sh dbchud.calc = #q dbchud.calc
scoreboard players operation #sh dbchud.calc /= #c4 dbchud.calc
execute store result storage dbchud:tmp sh int 1 run scoreboard players get #sh dbchud.calc
scoreboard players operation #slo dbchud.calc = #sh dbchud.calc
scoreboard players operation #slo dbchud.calc *= #c4 dbchud.calc
scoreboard players operation #slo dbchud.calc *= #cm1 dbchud.calc
scoreboard players operation #slo dbchud.calc += #q dbchud.calc
$scoreboard players set #g dbchud.calc $(x)
$scoreboard players set #b dbchud.calc $(y)
execute if score #slo dbchud.calc matches 1 run scoreboard players add #g dbchud.calc 128
execute if score #slo dbchud.calc matches 3 run scoreboard players add #g dbchud.calc 128
execute if score #slo dbchud.calc matches 2.. run scoreboard players add #b dbchud.calc 128
execute store result storage dbchud:tmp g int 1 run scoreboard players get #g dbchud.calc
execute store result storage dbchud:tmp b int 1 run scoreboard players get #b dbchud.calc
# color 先按预设名查(hud_style.json 的 presets,命中即为槽号);否则走 颜色×效果 网格
data modify storage dbchud:tmp slot set value -1
$data modify storage dbchud:tmp slot set from storage dbchud:consts presets."$(color)"
execute store result score #sl dbchud.calc run data get storage dbchud:tmp slot
data modify storage dbchud:tmp idx set value 15
$data modify storage dbchud:tmp idx set from storage dbchud:consts palette."$(color)"
data modify storage dbchud:tmp eff set value 0
$data modify storage dbchud:tmp eff set from storage dbchud:consts effects."$(effect)"
execute store result score #r dbchud.calc run data get storage dbchud:tmp idx
execute store result score #e dbchud.calc run data get storage dbchud:tmp eff
scoreboard players operation #e dbchud.calc *= #cw dbchud.calc
scoreboard players operation #r dbchud.calc += #e dbchud.calc
execute if score #sl dbchud.calc matches 0.. run scoreboard players operation #r dbchud.calc = #sl dbchud.calc
execute store result storage dbchud:tmp r int 1 run scoreboard players get #r dbchud.calc
$data modify storage dbchud:tmp text set value "$(text)"
$data modify storage dbchud:tmp align set value "$(align)"
function dbchud:_enc2 with storage dbchud:tmp
