$data modify storage dbchud:data players.p$(id).comps.$(name).text set value "$(text)"
function dbchud:_render
