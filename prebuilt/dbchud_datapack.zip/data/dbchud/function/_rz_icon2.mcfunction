data modify storage dbchud:rzc acc set from storage dbchud:rz acc
data modify storage dbchud:rzc add set value ""
$data modify storage dbchud:rzc add set from storage dbchud:icons map.$(name)
function dbchud:_rz_cat with storage dbchud:rzc
