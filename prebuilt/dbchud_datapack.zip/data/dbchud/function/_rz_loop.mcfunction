execute if data storage dbchud:rz parts[0] run function dbchud:_rz_one
