#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:sample_lightmap.glsl>
#moj_import <minecraft:globals.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

#define HUD_N 100.0
#define HUD_BIAS 524288.0
#define HUD_STEP 2048.0
#define HUD_STEP_S 262144.0
#define HUD_DYBIAS 64.0
#define HUD_BASE_Y 72.0

const vec3 HUD_COL[128] = vec3[128](vec3(0,0,0),vec3(0,0,170),vec3(0,170,0),vec3(0,170,170),vec3(170,0,0),vec3(170,0,170),vec3(255,170,0),vec3(170,170,170),vec3(85,85,85),vec3(85,85,255),vec3(85,255,85),vec3(85,255,255),vec3(255,85,85),vec3(255,85,255),vec3(255,255,85),vec3(255,255,255),vec3(0,0,0),vec3(0,0,170),vec3(0,170,0),vec3(0,170,170),vec3(170,0,0),vec3(170,0,170),vec3(255,170,0),vec3(170,170,170),vec3(85,85,85),vec3(85,85,255),vec3(85,255,85),vec3(85,255,255),vec3(255,85,85),vec3(255,85,255),vec3(255,255,85),vec3(255,255,255),vec3(0,0,0),vec3(0,0,170),vec3(0,170,0),vec3(0,170,170),vec3(170,0,0),vec3(170,0,170),vec3(255,170,0),vec3(170,170,170),vec3(85,85,85),vec3(85,85,255),vec3(85,255,85),vec3(85,255,255),vec3(255,85,85),vec3(255,85,255),vec3(255,255,85),vec3(255,255,255),vec3(0,0,0),vec3(0,0,170),vec3(0,170,0),vec3(0,170,170),vec3(170,0,0),vec3(170,0,170),vec3(255,170,0),vec3(170,170,170),vec3(85,85,85),vec3(85,85,255),vec3(85,255,85),vec3(85,255,255),vec3(255,85,85),vec3(255,85,255),vec3(255,255,85),vec3(255,255,255),vec3(0,0,0),vec3(0,0,170),vec3(0,170,0),vec3(0,170,170),vec3(170,0,0),vec3(170,0,170),vec3(255,170,0),vec3(170,170,170),vec3(85,85,85),vec3(85,85,255),vec3(85,255,85),vec3(85,255,255),vec3(255,85,85),vec3(255,85,255),vec3(255,255,85),vec3(255,255,255),vec3(0,0,0),vec3(0,0,170),vec3(0,170,0),vec3(0,170,170),vec3(170,0,0),vec3(170,0,170),vec3(255,170,0),vec3(170,170,170),vec3(85,85,85),vec3(85,85,255),vec3(85,255,85),vec3(85,255,255),vec3(255,85,85),vec3(255,85,255),vec3(255,255,85),vec3(255,255,255),vec3(0,0,0),vec3(0,0,170),vec3(0,170,0),vec3(0,170,170),vec3(170,0,0),vec3(170,0,170),vec3(255,170,0),vec3(170,170,170),vec3(85,85,85),vec3(85,85,255),vec3(85,255,85),vec3(85,255,255),vec3(255,85,85),vec3(255,85,255),vec3(255,255,85),vec3(255,255,255),vec3(255,215,0),vec3(255,255,255),vec3(255,255,255),vec3(255,255,255),vec3(255,255,255),vec3(255,255,255),vec3(255,255,255),vec3(255,255,255),vec3(255,255,255),vec3(255,255,255),vec3(255,255,255),vec3(255,255,255),vec3(255,255,255),vec3(255,255,255),vec3(255,255,255),vec3(255,255,255));
const int HUD_EFF[128] = int[128](0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
vec3 hudHue(float h) {
    float r = abs(h*6.0-3.0)-1.0, g = 2.0-abs(h*6.0-2.0), b = 2.0-abs(h*6.0-4.0);
    return clamp(vec3(r,g,b), 0.0, 1.0);
}

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
    texCoord0 = UV0;

    vec3 hudW = vec3(ProjMat[0][3], ProjMat[1][3], ProjMat[2][3]);
    if (dot(hudW, hudW) < 0.25 && Position.x > 300000.0) {
        vec2 vp = vec2(abs(2.0/ProjMat[0][0]), abs(2.0/ProjMat[1][1]));
        float vpxi = floor(vp.x + 0.5);
        float vpyi = floor(vp.y + 0.5);
        ivec3 cc = ivec3(Color.rgb * 255.0 + 0.5);
        bool isShadow = cc.r >= 128;
        int slot = cc.r & 127;
        int effect = HUD_EFF[slot];
        float raw = Position.x - floor(vpxi * 0.5) - HUD_BIAS;
        float sh = floor(raw / HUD_STEP_S);
        float rem1 = raw - sh * HUD_STEP_S;
        float f = floor(rem1 / HUD_STEP);
        float letter = (rem1 - f * HUD_STEP) - HUD_STEP * 0.5;
        float dy = f - HUD_DYBIAS;
        int scaleLo = ((cc.g >> 7) & 1) | (((cc.b >> 7) & 1) << 1);
        int q = scaleLo | (int(sh) << 2);
        float s = (float(q) + 1.0) / 16.0;
        int xq = cc.g & 127;
        int yq = cc.b & 127;
        float t = GameTime * 24000.0;
        vec3 col = HUD_COL[slot] / 255.0;
        if (isShadow) col *= 0.25;
        float alpha = vertexColor.a;
        if (effect == 3) s *= 1.0 + 0.12 * sin(t * 0.35);
        float ax = floor(float(xq) / HUD_N * vpxi + 0.5);
        float ay = floor(float(yq) / HUD_N * vpyi + 0.5);
        float ox = letter * s;
        float oy = dy + (Position.y - vpyi + HUD_BASE_Y) * s;
        if (effect == 1) { oy += 2.0 * sin(t * 0.30 + letter * 0.45); }
        else if (effect == 2) { float seed = floor(t*0.6)+letter;
            ox += (fract(sin(seed)*43758.5453)-0.5)*3.0; oy += (fract(sin(seed+17.3)*43758.5453)-0.5)*3.0; }
        else if (effect == 4) { col = hudHue(fract(t*0.004 + letter*0.02)); }
        else if (effect == 5) { alpha *= 0.65 + 0.35 * sin(t * 0.40); }
        else if (effect == 6) { float a = t*0.9;
            float rx = ox*cos(a)-oy*sin(a); float ry = ox*sin(a)+oy*cos(a); ox = rx; oy = ry; }
        gl_Position = ProjMat * ModelViewMat * vec4(ax + ox, ay + oy, Position.z, 1.0);
        vertexColor = vec4(col, alpha);
    }
}
